// Types
import type { IconSet } from '../composables/icons.js';
declare const aliases: import("../internal-types.js").IconAliases;
declare const fa: IconSet;
export { aliases, fa };
